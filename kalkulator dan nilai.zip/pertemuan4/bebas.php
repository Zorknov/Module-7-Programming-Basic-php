<!doctype html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
  </head>
  <body class="bg-cyan-100 flex items-center justify-center min-h-screen"></body>

  <?php
  $Siswa = "";
  $Tugas = "";
  $UTS ="";
  $UAS= "";
  $status= "";   
  $hasil= "";    


     if (isset($_POST['Hitung'])){
    $Siswa = $_POST['Siswa']; 
    $UTS = $_POST['UTS']; 
    $UAS = $_POST['UAS']; 
    $Tugas = $_POST['Tugas']; 
    $hasil = $_POST ['Hitung'];

   $nilai = ((30 / 100) * $UTS) + ((40 / 100) * $UAS) + ((30 / 100) * $Tugas);

   switch ($hasil) {
    case $nilai >= 80:
        $status = "A";
        break;
    case $nilai >= 70:
        $status = "B";
        break;
    case $nilai >= 60:
        $status = "C";
        break;
    case $nilai >= 50:
        $status = "D";
        break;
    default:
        $status = "E";
        break;
   }

}
           ?>


  <div class="bg-white p-8 rounded-lg shadow-lg w-100">
        <h2 class="text-2xl font-semibold text-center mb-6">Form Input NILAI Siswa</h2>

        <form action="" method="POST">
             <label for="">Nama Siswa</label>
            <input type="text" name="Siswa"
            class="w-full p-3 mb-3 border border-gray-300 rounded-lg mb-2" autocomplete="off" placeholder="Masukan Nama" value="<?php echo $Siswa; ?>">
              <label for="">Nilai Tugas</label>
            <input type="number" name="Tugas"
            class="w-full p-3 mb-3 border border-gray-300 rounded-lg mb-2" autocomplete="off" placeholder="Nilai Harian" value="<?php echo $Tugas; ?>">
              <label for="">Nilai UTS</label>
            <input type="number" name="UTS"
            class="w-full p-3 mb-3 border border-gray-300 rounded-lg mb-2" autocomplete="off" placeholder="Nilai UTS" value="<?php echo $UTS; ?>">
              <label for="">Nilai UAS</label>
            <input type="number" name="UAS"
            class="w-full p-3 mb-3 border border-gray-300 rounded-lg mb-2" autocomplete="off" placeholder="Nilai UAS" value="<?php echo $UAS; ?>">

            <input type="Submit" name="Hitung" value="Hitung" class="w-full p-3 mb-3 border border-gray-300 rounded-lg bg-orange-500 text-white
            hover:bg-orange-700">
            
            </form>
         </div>

         <div class="bg-white p-4 rounded-lg shadow-lg w-80 mx-5">
  <table class="border-collapse border border-gray-400 w-75">
  <thead>
    <tr>
      <th class="border border-gray-300 bg-black text-white">Nama Siswa</th>
      <th class="border border-gray-300 bg-black text-white">Nilai</th>
      <th class="border border-gray-300 bg-black text-white">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td</td>
      <td class="border border-gray-300 text-center"><?php echo $Siswa; ?></td>
      <td class="border border-gray-300 text-center"><?php echo $nilai; ?></td>
      <td class="border border-gray-300 text-center"><?php echo $status; ?></td>
    </tr>
  </tbody>
</table>
         </div>

  </body>
</html>

